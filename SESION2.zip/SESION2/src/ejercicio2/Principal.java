package ejercicio2;

import java.util.Random;

import ejercicio1.Cuenta;

public class Principal {


	private static int id;

	
	
	
	static class hilop extends Thread{ 
		
		public void run() {

			System.out.println("El hilo principal ha terminado");
		
		
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			for(int i=0 ; i<1 ; i++ ) {
				id=i;
			}
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" milisegundos");
			
			 try {
				 
				 
				Thread.sleep((int) (segundos));
				
				
				System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
				
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}


		}
		
		
		
		
		
		
		
		

	}
	static class hilo1 extends Thread{ 

		public void run() {
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			int id=1;
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" segundos");
			
			 try {
				 
				 
				Thread.sleep((int) (segundos));
				
				
				System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
				
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}


		}

	}
	static class hilo2 extends Thread{ 

		public void run() {
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			int id=2;
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" segundos");
			 try {
				 
				 
					Thread.sleep((int) (segundos));
					
					
					System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
					
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

		}

	}
	static class hilo3 extends Thread{ 

		public void run() {
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			int id=3;
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" segundos");
			 try {
				 
				 
					Thread.sleep((int) (segundos));
					
					
					System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
					
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

		}

	}
	static class hilo4 extends Thread{ 

		public void run() {
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			int id=4;
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" segundos");

			 try {
				 
				 
					Thread.sleep((int) (segundos));
					
					
					System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
					
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}

	}
	static class hilo5 extends Thread{ 

		public void run() {
			int segundos;
			Random r = new Random();


			segundos=r.nextInt(500,10000);

			int id=5;
			System.out.println("Hola, soy el hilo "+id+ " y voy a dormir "+segundos+" segundos");

			 try {
				 
				 
					Thread.sleep((int) (segundos));
					
					
					System.out.println("Hola soy el hilo "+id+" y ya me he despertado");
					
					
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		}

	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=0;i<5;i++) {
			
			hilop hp = new hilop();
			
			hp.start();
			
		}
		
		
		
		








	}

}
