package PRACTICAS2;

class ProcesadorArray extends Thread {
    private int[] array;
    private int inicio;
    private int fin;
    private int sumaParcial;

    public ProcesadorArray(int[] array, int inicio, int fin) {
        this.array = array;
        this.inicio = inicio;
        this.fin = fin;
        this.sumaParcial = 0;
    }

    @Override
    public void run() {
        for (int i = inicio; i <= fin; i++) {
            sumaParcial += array[i];
        }
        System.out.println("Hilo encargado de " + inicio + " a " + fin + " finalizado. Suma parcial: " + sumaParcial);
    }

    public int getSumaParcial() {
        return sumaParcial;
    }
}
 
public class ProcesamientoPorPartes {

    public static void main(String[] args) {
        int[] datos = new int[100];
        for (int i = 0; i < datos.length; i++) {
            datos[i] = i + 1; 
        }

        ProcesadorArray h1 = new ProcesadorArray(datos, 0, 24);
        ProcesadorArray h2 = new ProcesadorArray(datos, 25, 49);
        ProcesadorArray h3 = new ProcesadorArray(datos, 50, 74);
        ProcesadorArray h4 = new ProcesadorArray(datos, 75, 99);

        h1.start();
        h2.start();
        h3.start();
        h4.start();

        try {
            h1.join();
            h2.join();
            h3.join();
            h4.join();
        } catch (InterruptedException e) {
            System.out.println("El hilo principal fue interrumpido.");
        }

        int sumaTotal = h1.getSumaParcial() + h2.getSumaParcial() + 
                        h3.getSumaParcial() + h4.getSumaParcial();

        System.out.println("\n--- RESULTADO FINAL ---");
        System.out.println("La suma total del array es: " + sumaTotal); 
    }
}