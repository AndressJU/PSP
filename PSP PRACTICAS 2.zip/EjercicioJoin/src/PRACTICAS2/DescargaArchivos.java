package PRACTICAS2;

public class DescargaArchivos {
	
	static class Archivos extends Thread {
		
		private String nombreArchivo;
		private int numero;
		private int tiempoDescarga; 
		
		public Archivos(String nombreArchivo, int numero, int tiempoDescarga) {
			this.nombreArchivo = nombreArchivo;
			this.numero = numero;
			this.tiempoDescarga = tiempoDescarga;
		}

		@Override
		public void run() {
			
			System.out.println("Comienza la descarga del " + nombreArchivo + " " + numero);
			
			try {
				
				Thread.sleep(tiempoDescarga);
				
			} catch (InterruptedException e) {
				System.out.println("Descarga " + numero + " interrumpida.");
			}
			

			System.out.println("La descarga del " + nombreArchivo + " " + numero + " ha terminado!");
		}
	}

	public static void main(String[] args) throws InterruptedException {
		
		Archivos h1 = new Archivos("Archivo", 1, 3000);
		Archivos h2 = new Archivos("Archivo", 2, 2000);
		Archivos h3 = new Archivos("Archivo", 3, 4000);

		h1.start();
		h2.start();
		h3.start();
		
		h1.join();
		h2.join();
		h3.join();
		
		
		System.out.println("Todas las descargas han finalizado");
	}
}