package inicio;

public class Trabajador extends Thread{

	 private String nombre;

	 public Trabajador(String nombre) {
		super();
		this.nombre = nombre;
	}

	 public String getNombre() {
		return nombre;
	}

	 public void setNombre(String nombre) {
		 this.nombre = nombre;
	 }

	 public void run() {
		 
		 String trabajador1="";
		 String trabajador2="";
		 String trabajador3="";

		 int totalM=100;
		 int totalE=10;
		 System.out.println("--------------INICIA LA CARRERA--------------");
		 
		
		 for(int i = 0; i<11; i++) {
			 
			 totalM =- totalE;
			 
			 System.out.println(getNombre()+ " HA COMPLETADO LA ETAPA "+ i);
			 System.out.println(getNombre()+ " LLEVA "+ (i * totalE)+ " metros");
			 System.out.println("------------------------");
			 
			 if(i==10) {
				 
				 System.out.println(getNombre()+ "HA GANADOOO!!!!!1");

			 }
			 try {
				
				 Thread.sleep((int) (Math.random() * 1000) + 500);
				
				 
				 
				 
				 
			} catch (InterruptedException e) {
				System.out.println("Carrera Interrumpida");
				return;
			}
		 }
		 
		 }
		 
		 
		 
		 
	 }


