package inicio;

public class Carrera {

	
	private int totalM;
	private int totalE;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int totalM=0;
		int totalE=0;

	
		System.out.println("---------------CARRERA DE TRABAJADORES---------------");
	
		
		
		
		while(totalE==10) {
			
			
			
		}
		
	}
	
	

}
