package inicio;

public class HiloLetras extends Thread{

	
public void run() {
		
		for(char letra = 'a'; letra <= 'e'; letra++) {
			System.out.println(letra);
		}
		
	}
}
