package inicio;

public class Logica {

	public static void main(String[] args) {
		
		
		Trabajador Mario = new Trabajador("Mario");
		Trabajador Andres= new Trabajador("Andres");
		Trabajador Oscar= new Trabajador("Oscar");

		Mario.start();
		Andres.start();
		Oscar.start();


//numeros 1-5, letras a-e, mensaje imprime 5 veces
	}
	
	
}
