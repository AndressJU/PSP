package inicio;

public class HiloAdios extends Thread {

	
	@Override
	public void run()  {

		for(int i=0;i<3;i++) {
			System.out.println("adios");
		}

	}
	

	}

	

