package inicio;

public class PrimerHilo  extends Thread {

	
	public void run( ){
		System.out.println("Hola desde dentro del hilo");
	}
	
}
