package inicio;

public class HiloMensajes extends Thread{

	
public void run() {
		
		System.out.println("mensaje1");
		System.out.println("mensaje2");
		System.out.println("mensaje3");
		System.out.println("mensaje4");
		System.out.println("mensaje5");

		
	}
}
