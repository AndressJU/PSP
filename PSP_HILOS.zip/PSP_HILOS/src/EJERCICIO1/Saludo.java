package EJERCICIO1;

public class Saludo extends Thread{

	private int condicion;

	public Saludo( int condicion) {
		this.condicion=condicion;
	}


	private void hola()  {

		for(int i=0;i<3;i++) {
			System.out.println("Hola");
		}

	}
	private void adios()  {

		for(int i=0;i<3;i++) {
			System.out.println("adios");
		}

	}








	public void run() {
		if(condicion==1) {
			hola();
		}else {
			adios();
		}


	}











}
