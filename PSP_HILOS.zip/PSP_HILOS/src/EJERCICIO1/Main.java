package EJERCICIO1;

public class Main {

	public static void main(String[] args) {

		Saludo h1= new Saludo(1);
		h1.start();
		Saludo h2= new Saludo(2);
		h2.start();
	
	}

}
