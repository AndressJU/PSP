
package ejercicio2;

import java.util.Random;

public class Principal {

    static class hilop extends Thread {

        private int id;

        public hilop(int id) {
            this.id = id;
        }

        public void run() {

            int segundos;
            Random r = new Random();

            segundos = r.nextInt(500, 10000);

            System.out.println("Hola, soy el hilo " + id +" y voy a dormir " + segundos + " milisegundos");

            try {

                Thread.sleep(segundos);

                System.out.println("Hola, soy el hilo " + id +" y ya me he despertado");

            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    public static void main(String[] args) {

        for (int i = 1; i <= 5; i++) {

            hilop hp = new hilop(i);

            hp.start();

        }

        System.out.println("El hilo principal ha terminado");

    }

}
