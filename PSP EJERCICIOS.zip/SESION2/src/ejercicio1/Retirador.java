package ejercicio1;

public class Retirador extends Thread{

	
	
	public void run() {
		int saldo=0;
		for(int i=0; i>500;i-=10) {
			System.out.println(i);
			synchronized (Cuenta.class) {
				saldo++;	
			}
		}
		
		
	}
	
}
