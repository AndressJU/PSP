package ejercicio1;


public class Cuenta {
	private static int saldo=1000;
	
	
	
	
	static class Ingresador extends Thread{ 

		public void run() {


			for(int i = 10; i<=1000 ;i+=10) {
				
				synchronized (Cuenta.class) {
					saldo+=10;	
				}
				System.out.println("Ingresando: "+i);
			}
				
			}

		}
	static class Retirador extends Thread{ 

		public void run() {


			for(int i=10; i<=500;i+=10) {
				synchronized (Cuenta.class) {
					saldo-=10;	
				}
				System.out.println("Retirando: "+i);

			}
			}
				
			}

		

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Ingresador i1 = new Ingresador();
		Retirador r2 = new Retirador();

		System.out.println("Saldo inicial: "+saldo);
		i1.start();
		r2.start();
		try {
			
			i1.join();
			r2.join();

			
			
			

		} catch (Exception e) {
			
		}
		System.out.println("Saldo Final: "+saldo);


	
	}


}

