package ejercicio1;

public class Ingresador extends Thread{




	public void run() {

		int saldo=0;
		for(int i = 0; i<1000 ;i+=10) {
			System.out.println(i);
			synchronized (Cuenta.class) {
				saldo++;	
			}
		}



	}

	


}
