package INICIO;

public class Principal {

	private static int contador=0;


	static class Incrementador extends Thread{ 

		public void run() {


			for(int i=0; i<100000; i ++) {
				synchronized (Principal.class) {
					contador++;	
				}
				
			}

		}


	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub


		Incrementador i1 = new Incrementador();
		Incrementador i2 = new Incrementador();


		i1.start();
		i2.start();
		try {
			i1.join();
			i2.start();

			
			
		} catch (Exception e) {
			
		}
		

		System.out.println("Contador final: "+contador);
	}

}
