package PRACTICAS1;

import java.awt.Frame;

public class EJ2_Start_Run {

	static class hilos extends Thread{







		public void run() {
			String nombreHilo= Thread.currentThread().getName();
			
			System.out.println("Codigo ejecutado por el hilo: "+nombreHilo);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("El hilo principal se llama: " + Thread.currentThread().getName());
        System.out.println("--------------------------------------------------");

		hilos h1= new hilos();
		h1.run(); 
        
        
        hilos h2= new hilos();
		h2.setName("Trabajador");
		h2.start();
        System.out.println("--------------------------------------------------");


	}

}
