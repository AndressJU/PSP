package PRACTICAS1;

import java.awt.Frame;

public class EJ1_Contadores {
	static class Contador extends Frame implements Runnable{

		
		private int N;
		private String nombre;

		public Contador(String nombre, int N) {
			this.nombre=nombre;
			this.N=N;
			
		}
		
		@Override
		public void run() {

			for (int i = 1; i <= N; i++) {
	            System.out.println("Contador " + nombre + ": " + i);
	        }
			
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		 Contador a = new Contador("Contador A",5);
		 Contador b = new Contador("Contador B",10);
		 Contador c = new Contador("Contador C",15);


		Thread t1 = new Thread(a);
		Thread t2 = new Thread(b);
		Thread t3 = new Thread(c);


		t1.start();
		t2.start();
		t3.start();

	}
}
	
