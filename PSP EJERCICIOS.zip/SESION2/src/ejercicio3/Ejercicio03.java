package ejercicio3;

import java.util.concurrent.ThreadLocalRandom;

public class Ejercicio03 {
    static class Dormilon extends Thread {
        private final int id;
        public Dormilon(int id) { 
        	this.id = id; 
        	
        	} 

        @Override
        public void run() {
            int x = ThreadLocalRandom.current().nextInt(500, 10_001);
            System.out.println("Hola, soy el hilo " + id + " y voy a dormir " + x + " milisegundos");
            try {
                Thread.sleep(x);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
            System.out.println("Hola, soy el hilo " + id + " y ya me he despertado.");
        }
    }

    public static void main(String[] args) {
    	Dormilon[] hilos = new Dormilon[5];
        for (int i = 0; i < hilos.length; i++) {
            hilos[i] = new Dormilon(i);
            hilos[i].start();
        }
        System.out.println("El hilo principal ha terminado");
    }
}